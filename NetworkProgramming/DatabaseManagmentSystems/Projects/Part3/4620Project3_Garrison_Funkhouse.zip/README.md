Project:

    This java program will interact with my database in AWS RDS and control many of the attributes of the table. There were a few helper
    functions written in DBNinja to help with updating some of the values. I also updated some of the code in main to make it a little 
    better such as adding a feature to say "there are no open orders" if 4 is entered and there are no orders in.

